## Introduction
For my CS51 final project extensions, I implemented a lexical environment evaluator and floats. 

## Lexical Environment Evaluator
The lexical environment evaluator is extremely similar to the dynamic environment evaluator. In fact, for all match cases besides Fun, Letrec, and App, the two are identical. In order to reduce redundancy and abstract out these similarities, I first made a variant type called environmental. Environmental included two variants—Dynamic and Lexical—that indicated whether the evaluation was to be performed in a dynamic or lexical environment. Then, I made a function called eval_envir that accepted an expression, environment, and environmental argument. This function used match statements with the environmental argument in the Fun, Letrec, and App match cases to determine whether it should perform the dynamic- or lexical-specific evaluation rules. Eval_d and eval_l then simply called upon  eval_envir with the appropriate environmental argument to perform their respective evaluations.  

**Code block containing the environmental variant type (evaluations.ml line 190)**
    type environmental = 
        | Dynamic
        | Lexical ;;

**Code block example of a case in the enval_envir in which a match statement with the environmental argument is necessary (evaluations.ml line 209)**
    | Fun _ -> 
        (match env_type with 
        | Dynamic -> Env.Val exp
        | Lexical -> Env.close exp env)

**Code block example of eval_d calling eval_envir (evaluations.ml line 285)**
    let rec eval_d (exp : expr) (env : Env.env) : Env.value =
        eval_envir exp env Dynamic ;;

As mentioned before, the difference between dynamic and lexical evaluations are contained within evaluations for functions, recursive let statements, and function applications. For functions, dynamic evaluations simply return the function itself whereas lexical evaluations return a closure that is represented by a tuple of a function expression and environment. For recursive let statements, dynamic evaluations can simply return the same thing that is returned by non-recursive let statements. In contrast, lexical evaluations must create a temporary placeholder definition for the function using a ref Unassigned before replacing the placeholder definition with the base case evaluation after the recursion has finished running its course. Finally, function applications in dynamic environments can simply occur in the environment present at the time of application, but for lexical evaluations, the evaluator must lookup a closure associated with the function, extract the lexical environment in the closure, and perform the evaluation in this lexical environment. 

**Code block example of code that defines lexical evaluations for functions (evaluations.ml line 212)**
    | Lexical -> Env.close exp env)

**Code block example of code that defines lexical evaluations for recursive let statements (evaluations.ml line 253)**
    | Lexical -> 
        let temp = ref (Env.Val Unassigned) in 
        temp := eval_envir expr1 (Env.extend env x temp) env_type; 
        eval_envir expr2 (Env.extend env x temp) env_type)

**Code block example of code that defines lexical evaluations for function application (evaluations.ml line 273)**
    | Lexical -> 
        match eval_envir expr1 env env_type with 
        | Env.Closure (Fun (x, b), env_l) -> 
            eval_envir b 
                       (Env.extend env_l x (ref (eval_envir expr2 env env_type))) 
                       env_type
        | _ -> raise (EvalError "function application on non-function"));;  


## Floats
I also implemented floats as part of my extensions. I first added a type Float of float to the expr variant type in the expr.ml and expr.mli files. In order to make float evaluations strongly typed, I also added Fplus, Fminus, and Ftimes binop operations to the binop variant type in the expr.ml and expr.mli files. In addition, I also implemented a Power function for floats.

**Code containing the additions of floats and float operations in expr.ml (line 14)**
    type binop =
    | Plus
    | Minus
    | Times
    | Equals
    | LessThan
    | Fplus
    | Fminus
    | Ftimes
    | Power
    ;;

    type varid = string ;;
    
    type expr =
    | Var of varid                         (* variables *)
    | Num of int                           (* integers *)
    | Float of float                       (* floats *)
    | Bool of bool                         (* booleans *)
    | Unop of unop * expr                  (* unary operators *)
    | Binop of binop * expr * expr         (* binary operators *)
    | Conditional of expr * expr * expr    (* if then else *)
    | Fun of varid * expr                  (* function definitions *)
    | Let of varid * expr * expr           (* local naming *)
    | Letrec of varid * expr * expr        (* recursive local naming *)
    | Raise                                (* exceptions *)
    | Unassigned                           (* (temporarily) unassigned *)
    | App of expr * expr                   (* function applications *)
    ;;

In order to implement these operations, I had to modify my evaluator functions. In my Binop match cases for eval_s and eval_envir, I included a case for if both expressions in the Binop evaluated to floats. If both expressions evaluated to floats, then the binary operation within the Binop was matched with the float-compatible operations and evaluated. If the binary operation was not float-compatible, then an error was raised. An error case was also added to the case in which both expressions within the Binop evaluated to integers but the binop was not float-compatible. 

**Code implementing float operation evaluations (evaluation.ml line 234)**
    | Env.Val Float x, Env.Val Float y -> 
        (match binop with 
        | Fplus -> Env.Val (Float (x +. y))
        | Fminus -> Env.Val (Float (x -. y))
        | Ftimes -> Env.Val (Float (x *. y))
        | Equals -> Env.Val (Bool (x = y))
        | LessThan -> Env.Val (Bool (x < y))
        | Power -> Env.Val (Float (x ** y))
        | _ -> raise (EvalError "int operation on float"))

In order to get the parser to recognize floats and my new float operations, I had to modify the miniml_parse.mly and miniml_lex.mll files. In the parse file, I introduced tokens for floats and all the new operations. I also added grammar rules for floats and the operations. In the lex file, I added regular expressions for floats and a rule for floats. I also added symbols for the operations to the symbols table. 

**Code adding tokens for floats and the new float operations (miniml_parse.mly line 22)**
    %token <float> FLOAT
    %token TRUE FALSE
    %token FPLUS FMINUS
    %token FTIMES
    %token POWER

